# textminer-pro

텍스트 전처리, 키워드 추출, 요약, 언어 감지를 제공하는 Python 패키지입니다.

## 설치 (TestPyPI 기준)

```bash
pip install -i https://test.pypi.org/simple/ textminer-pro
